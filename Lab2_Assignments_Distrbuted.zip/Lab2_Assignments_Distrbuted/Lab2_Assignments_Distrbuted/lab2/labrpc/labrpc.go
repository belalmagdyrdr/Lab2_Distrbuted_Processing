// Package labrpc is a SMALL STAND-IN for the course's labrpc package.
// It only exists so you can try raft.go before you get the official starter
// code. Delete this folder and use the official one for grading.
//
// Like the real labrpc it simulates an unreliable network in memory:
// calls are copied (no shared memory), delayed, and can be dropped.
package labrpc

import (
	"bytes"
	"encoding/gob"
	"math/rand"
	"reflect"
	"sync"
	"time"
)

type Network struct {
	mu       sync.Mutex
	reliable bool
	enabled  map[int]bool
	services map[int]interface{}
}

func MakeNetwork() *Network {
	return &Network{reliable: true, enabled: map[int]bool{}, services: map[int]interface{}{}}
}

// Reliable(false) makes the network drop ~10% of messages and delay more.
func (n *Network) Reliable(yes bool) {
	n.mu.Lock()
	n.reliable = yes
	n.mu.Unlock()
}

// AddServer registers peer i; its exported methods are callable as "Raft.Method".
func (n *Network) AddServer(i int, svc interface{}) {
	n.mu.Lock()
	n.services[i] = svc
	n.enabled[i] = true
	n.mu.Unlock()
}

// Enable connects/disconnects peer i (affects calls to AND from it).
func (n *Network) Enable(i int, yes bool) {
	n.mu.Lock()
	n.enabled[i] = yes
	n.mu.Unlock()
}

type ClientEnd struct {
	net      *Network
	from, to int
}

func (n *Network) MakeEnd(from, to int) *ClientEnd {
	return &ClientEnd{net: n, from: from, to: to}
}

func (n *Network) state(from, to int) (ok bool, reliable bool, svc interface{}) {
	n.mu.Lock()
	defer n.mu.Unlock()
	return n.enabled[from] && n.enabled[to], n.reliable, n.services[to]
}

func clone(dst, src interface{}) {
	var buf bytes.Buffer
	if err := gob.NewEncoder(&buf).Encode(src); err != nil {
		panic(err)
	}
	if err := gob.NewDecoder(&buf).Decode(dst); err != nil {
		panic(err)
	}
}

// Call returns false if the message or reply was lost.
func (e *ClientEnd) Call(svcMeth string, args interface{}, reply interface{}) bool {
	up, reliable, svc := e.net.state(e.from, e.to)
	fail := func() bool {
		time.Sleep(time.Duration(rand.Intn(30)) * time.Millisecond)
		return false
	}
	if !up || svc == nil {
		return fail()
	}
	if !reliable {
		time.Sleep(time.Duration(rand.Intn(27)) * time.Millisecond)
		if rand.Intn(1000) < 100 {
			return fail()
		}
	}
	// Method name after "Raft."
	name := svcMeth
	for i := 0; i < len(svcMeth); i++ {
		if svcMeth[i] == '.' {
			name = svcMeth[i+1:]
		}
	}
	m := reflect.ValueOf(svc).MethodByName(name)
	if !m.IsValid() {
		return fail()
	}
	a := reflect.New(m.Type().In(0).Elem())
	clone(a.Interface(), args)
	r := reflect.New(m.Type().In(1).Elem())
	m.Call([]reflect.Value{a, r})

	// Reply may be lost if either side got disconnected meanwhile.
	up, reliable, _ = e.net.state(e.from, e.to)
	if !up {
		return fail()
	}
	if !reliable && rand.Intn(1000) < 100 {
		return fail()
	}
	clone(reply, r.Interface())
	return true
}
