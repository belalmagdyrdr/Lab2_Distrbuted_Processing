@echo off
cd /d "%~dp0"
echo === Lab 2: run everything ===

where gcc >nul 2>nul
if errorlevel 1 (
  echo gcc was not found. Installing it with winget...
  winget install -e --id BrechtSanders.WinLibs.POSIX.UCRT
  echo.
  echo Done. CLOSE this window, open a NEW cmd window, and run run_all.bat again.
  pause
  exit /b 1
)

set CGO_ENABLED=1
set OUT=results.txt
echo Lab 2 results > %OUT%

echo ### go vet ./... >> %OUT%
go vet ./... >> %OUT% 2>&1

echo ### go test -count=1 ./... -v >> %OUT%
go test -count=1 ./... -v >> %OUT% 2>&1

echo ### go test -race -count=1 ./... >> %OUT%
go test -race -count=1 ./... >> %OUT% 2>&1

type %OUT%
echo.
echo Results were also saved in results.txt. Take your screenshot now.
pause
