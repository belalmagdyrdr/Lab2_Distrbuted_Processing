package raft

// Stand-in tests for trying raft.go before you have the official tests.
// Delete this file once you have the instructor's test_test.go / config.go.

import (
	"fmt"
	"sync"
	"testing"
	"time"

	"lab2/labrpc"
)

type cluster struct {
	t         *testing.T
	net       *labrpc.Network
	n         int
	rafts     []*Raft
	connected []bool
	mu        sync.Mutex
	logs      []map[int]interface{}
	lastIdx   []int
	failure   string
}

func makeCluster(t *testing.T, n int) *cluster {
	c := &cluster{t: t, net: labrpc.MakeNetwork(), n: n,
		rafts: make([]*Raft, n), connected: make([]bool, n),
		logs: make([]map[int]interface{}, n), lastIdx: make([]int, n)}
	for i := 0; i < n; i++ {
		c.logs[i] = map[int]interface{}{}
		c.connected[i] = true
	}
	for i := 0; i < n; i++ {
		ends := make([]*labrpc.ClientEnd, n)
		for j := 0; j < n; j++ {
			ends[j] = c.net.MakeEnd(i, j)
		}
		applyCh := make(chan ApplyMsg)
		rf := Make(ends, i, applyCh)
		c.rafts[i] = rf
		c.net.AddServer(i, rf)
		go c.apply(i, applyCh)
	}
	t.Cleanup(func() {
		for _, rf := range c.rafts {
			rf.Kill()
		}
	})
	return c
}

func (c *cluster) apply(i int, ch chan ApplyMsg) {
	for m := range ch {
		c.mu.Lock()
		if m.Index != c.lastIdx[i]+1 && c.failure == "" {
			c.failure = fmt.Sprintf("server %d applied index %d, expected %d", i, m.Index, c.lastIdx[i]+1)
		}
		for j := 0; j < c.n; j++ {
			if old, ok := c.logs[j][m.Index]; ok && old != m.Command && c.failure == "" {
				c.failure = fmt.Sprintf("index %d differs: server %d has %v, server %d has %v", m.Index, j, old, i, m.Command)
			}
		}
		c.logs[i][m.Index] = m.Command
		c.lastIdx[i] = m.Index
		c.mu.Unlock()
	}
}

func (c *cluster) disconnect(i int) { c.connected[i] = false; c.net.Enable(i, false) }
func (c *cluster) connect(i int)    { c.connected[i] = true; c.net.Enable(i, true) }

// checkOneLeader waits up to ~5s for exactly one leader among connected peers.
func (c *cluster) checkOneLeader() int {
	for iter := 0; iter < 25; iter++ {
		time.Sleep(200 * time.Millisecond)
		leaders := map[int][]int{}
		for i := 0; i < c.n; i++ {
			if c.connected[i] {
				if term, ok := c.rafts[i].GetState(); ok {
					leaders[term] = append(leaders[term], i)
				}
			}
		}
		last := -1
		for term, ls := range leaders {
			if len(ls) > 1 {
				c.t.Fatalf("term %d has %d leaders", term, len(ls))
			}
			if term > last {
				last = term
			}
		}
		if len(leaders) > 0 {
			return leaders[last][0]
		}
	}
	c.t.Fatal("expected one leader, got none")
	return -1
}

func (c *cluster) checkNoLeader() {
	for i := 0; i < c.n; i++ {
		if c.connected[i] {
			if _, ok := c.rafts[i].GetState(); ok {
				c.t.Fatalf("server %d is leader but should not be", i)
			}
		}
	}
}

func (c *cluster) nCommitted(index int) (int, interface{}) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.failure != "" {
		c.t.Fatal(c.failure)
	}
	count := 0
	var cmd interface{}
	for i := 0; i < c.n; i++ {
		if v, ok := c.logs[i][index]; ok {
			if count > 0 && v != cmd {
				c.t.Fatalf("committed values differ at index %d: %v vs %v", index, cmd, v)
			}
			count++
			cmd = v
		}
	}
	return count, cmd
}

// one submits cmd and waits until `expected` servers committed it.
func (c *cluster) one(cmd int, expected int) int {
	start := time.Now()
	for time.Since(start) < 10*time.Second {
		for i := 0; i < c.n; i++ {
			if !c.connected[i] {
				continue
			}
			index, _, ok := c.rafts[i].Start(cmd)
			if !ok {
				continue
			}
			t1 := time.Now()
			for time.Since(t1) < 2*time.Second {
				if n, v := c.nCommitted(index); n >= expected && v == cmd {
					return index
				}
				time.Sleep(20 * time.Millisecond)
			}
		}
		time.Sleep(50 * time.Millisecond)
	}
	c.t.Fatalf("one(%d) failed to reach agreement", cmd)
	return -1
}

// ---------------- 3A ----------------

func TestStandin3AInitialElection(t *testing.T) {
	c := makeCluster(t, 3)
	c.checkOneLeader()
	term1, _ := c.rafts[0].GetState()
	time.Sleep(2 * time.Second)
	term2, _ := c.rafts[0].GetState()
	if term1 != term2 {
		t.Fatalf("term changed (%d -> %d) with no failures", term1, term2)
	}
	c.checkOneLeader()
}

func TestStandin3AReElection(t *testing.T) {
	c := makeCluster(t, 3)
	leader1 := c.checkOneLeader()
	c.disconnect(leader1)
	c.checkOneLeader() // new leader among the other two
	c.connect(leader1)
	leader2 := c.checkOneLeader()
	c.disconnect(leader2)
	c.disconnect((leader2 + 1) % 3)
	time.Sleep(2 * time.Second)
	c.checkNoLeader() // no majority -> no leader
	c.connect((leader2 + 1) % 3)
	c.checkOneLeader()
	c.connect(leader2)
	c.checkOneLeader()
}

// ---------------- 3B ----------------

func TestStandin3BBasicAgree(t *testing.T) {
	c := makeCluster(t, 3)
	c.checkOneLeader()
	for i := 1; i <= 3; i++ {
		idx := c.one(i*100, 3)
		if idx != i {
			t.Fatalf("got index %d, want %d", idx, i)
		}
	}
}

func TestStandin3BFailAgree(t *testing.T) {
	c := makeCluster(t, 3)
	c.one(101, 3)
	leader := c.checkOneLeader()
	c.disconnect((leader + 1) % 3)
	c.one(102, 2)
	c.one(103, 2)
	c.connect((leader + 1) % 3)
	c.one(104, 3) // follower must catch up
}

func TestStandin3BLeaderFailureAndConflict(t *testing.T) {
	c := makeCluster(t, 5)
	c.one(1, 5)
	leader := c.checkOneLeader()
	// Old leader accepts entries that can never commit (it is alone).
	c.disconnect((leader + 1) % 5)
	c.disconnect((leader + 2) % 5)
	c.disconnect((leader + 3) % 5)
	for i := 0; i < 5; i++ {
		c.rafts[leader].Start(1000 + i)
	}
	time.Sleep(500 * time.Millisecond)
	// Swap partitions: old leader + one peer go away, the other three return.
	c.disconnect(leader)
	c.disconnect((leader + 4) % 5)
	c.connect((leader + 1) % 5)
	c.connect((leader + 2) % 5)
	c.connect((leader + 3) % 5)
	for i := 0; i < 5; i++ {
		c.one(2000+i, 3)
	}
	// Heal everything: the old leader's uncommitted entries must be replaced.
	c.connect(leader)
	c.connect((leader + 4) % 5)
	c.one(3000, 5)
}

func TestStandin3BUnreliableAgree(t *testing.T) {
	c := makeCluster(t, 5)
	c.net.Reliable(false)
	c.checkOneLeader()
	var wg sync.WaitGroup
	for k := 0; k < 4; k++ {
		wg.Add(1)
		go func(k int) {
			defer wg.Done()
			for j := 0; j < 10; j++ {
				c.one(k*100+j+1, 1)
			}
		}(k)
	}
	wg.Wait()
	c.net.Reliable(true)
	c.one(9999, 5)
}
