// Package raft implements the core Raft consensus algorithm (Lab 2):
// leader election, heartbeats, log replication and commitment.
// Persistence, snapshots, and membership changes are out of scope.
package raft

import (
	"math/rand"
	"sync"
	"time"

	"lab2/labrpc" // adjust to your module path (see go.mod)
)

const (
	heartbeatInterval  = 110 * time.Millisecond // < 10 heartbeats per second
	electionTimeoutMin = 300                    // milliseconds
	electionTimeoutRng = 200                    // random extra milliseconds
	tickInterval       = 10 * time.Millisecond
)

type state int

const (
	Follower state = iota
	Candidate
	Leader
)

// ApplyMsg is sent on applyCh for every committed entry.
// KEEP the fields from your starter code; UseSnapshot/Snapshot are ignored.
type ApplyMsg struct {
	Index       int
	Command     interface{}
	UseSnapshot bool
	Snapshot    []byte
}

// LogEntry is one entry of the replicated log.
type LogEntry struct {
	Term    int
	Command interface{}
}

// Raft is one peer.
type Raft struct {
	mu      sync.Mutex
	applyMu *sync.Cond
	peers   []*labrpc.ClientEnd
	me      int
	applyCh chan ApplyMsg
	dead    bool

	// persistent state (kept in memory only for this lab)
	currentTerm int
	votedFor    int
	log         []LogEntry // log[0] is a dummy entry; real indexes start at 1

	// volatile state
	commitIndex int
	lastApplied int
	state       state

	// leader state
	nextIndex  []int
	matchIndex []int

	// timers
	electionReset   time.Time
	electionTimeout time.Duration
	lastBroadcast   time.Time
}

// ---------- RPC argument / reply types (exported fields only) ----------

type RequestVoteArgs struct {
	Term         int
	CandidateId  int
	LastLogIndex int
	LastLogTerm  int
}

type RequestVoteReply struct {
	Term        int
	VoteGranted bool
}

type AppendEntriesArgs struct {
	Term         int
	LeaderId     int
	PrevLogIndex int
	PrevLogTerm  int
	Entries      []LogEntry
	LeaderCommit int
}

type AppendEntriesReply struct {
	Term    int
	Success bool
	// Fast log-backup hints.
	ConflictIndex int
	ConflictTerm  int
}

// ---------- public interface ----------

// Make creates a Raft peer. It returns quickly; work runs in goroutines.
func Make(peers []*labrpc.ClientEnd, me int, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{
		peers:    peers,
		me:       me,
		applyCh:  applyCh,
		votedFor: -1,
		log:      []LogEntry{{Term: 0}},
		state:    Follower,
	}
	rf.applyMu = sync.NewCond(&rf.mu)
	rf.nextIndex = make([]int, len(peers))
	rf.matchIndex = make([]int, len(peers))
	rf.resetElectionTimer()

	go rf.ticker()
	go rf.applier()
	return rf
}

// GetState returns the current term and whether this peer believes it is leader.
func (rf *Raft) GetState() (int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	return rf.currentTerm, rf.state == Leader
}

// Start begins agreement on a command. It never waits for replication.
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if rf.dead || rf.state != Leader {
		return -1, -1, false
	}
	rf.log = append(rf.log, LogEntry{Term: rf.currentTerm, Command: command})
	index := len(rf.log) - 1
	rf.matchIndex[rf.me] = index
	rf.nextIndex[rf.me] = index + 1
	rf.broadcastLocked()
	return index, rf.currentTerm, true
}

// Kill stops this peer's background goroutines (the "Stop" of Lab 1).
func (rf *Raft) Kill() {
	rf.mu.Lock()
	rf.dead = true
	rf.applyMu.Broadcast()
	rf.mu.Unlock()
}

// ---------- helpers (caller must hold rf.mu) ----------

func (rf *Raft) resetElectionTimer() {
	rf.electionReset = time.Now()
	rf.electionTimeout = time.Duration(electionTimeoutMin+rand.Intn(electionTimeoutRng)) * time.Millisecond
}

// becomeFollower moves to a (possibly newer) term as follower.
func (rf *Raft) becomeFollower(term int) {
	if term > rf.currentTerm {
		rf.currentTerm = term
		rf.votedFor = -1
	}
	rf.state = Follower
}

func (rf *Raft) lastLogIndex() int { return len(rf.log) - 1 }
func (rf *Raft) lastLogTerm() int  { return rf.log[len(rf.log)-1].Term }

// ---------- background loops ----------

func (rf *Raft) ticker() {
	for {
		time.Sleep(tickInterval)
		rf.mu.Lock()
		if rf.dead {
			rf.mu.Unlock()
			return
		}
		if rf.state == Leader {
			if time.Since(rf.lastBroadcast) >= heartbeatInterval {
				rf.broadcastLocked()
			}
		} else if time.Since(rf.electionReset) >= rf.electionTimeout {
			rf.startElectionLocked()
		}
		rf.mu.Unlock()
	}
}

// applier delivers committed entries to the service in order. The channel
// send happens WITHOUT holding the lock so RPC handlers keep making progress.
func (rf *Raft) applier() {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	for !rf.dead {
		if rf.lastApplied < rf.commitIndex {
			rf.lastApplied++
			msg := ApplyMsg{Index: rf.lastApplied, Command: rf.log[rf.lastApplied].Command}
			rf.mu.Unlock()
			rf.applyCh <- msg
			rf.mu.Lock()
		} else {
			rf.applyMu.Wait()
		}
	}
}

// ---------- leader election ----------

func (rf *Raft) startElectionLocked() {
	rf.state = Candidate
	rf.currentTerm++
	rf.votedFor = rf.me
	rf.resetElectionTimer()

	term := rf.currentTerm
	votes := 1
	args := RequestVoteArgs{
		Term:         term,
		CandidateId:  rf.me,
		LastLogIndex: rf.lastLogIndex(),
		LastLogTerm:  rf.lastLogTerm(),
	}
	for i := range rf.peers {
		if i == rf.me {
			continue
		}
		go func(i int) {
			var reply RequestVoteReply
			ok := rf.peers[i].Call("Raft.RequestVote", &args, &reply)
			rf.mu.Lock()
			defer rf.mu.Unlock()
			// Ignore failures and stale replies.
			if !ok || rf.dead || rf.state != Candidate || rf.currentTerm != term {
				return
			}
			if reply.Term > rf.currentTerm {
				rf.becomeFollower(reply.Term)
				rf.resetElectionTimer()
				return
			}
			if reply.VoteGranted {
				votes++
				if votes*2 > len(rf.peers) {
					rf.becomeLeaderLocked()
				}
			}
		}(i)
	}
}

func (rf *Raft) becomeLeaderLocked() {
	rf.state = Leader
	for i := range rf.peers {
		rf.nextIndex[i] = len(rf.log)
		rf.matchIndex[i] = 0
	}
	rf.matchIndex[rf.me] = rf.lastLogIndex()
	rf.broadcastLocked() // immediate heartbeat
}

// RequestVote RPC handler.
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	if args.Term > rf.currentTerm {
		rf.becomeFollower(args.Term)
	}
	reply.Term = rf.currentTerm
	reply.VoteGranted = false
	if args.Term < rf.currentTerm {
		return
	}
	// Election restriction: candidate's log must be at least as up to date.
	upToDate := args.LastLogTerm > rf.lastLogTerm() ||
		(args.LastLogTerm == rf.lastLogTerm() && args.LastLogIndex >= rf.lastLogIndex())
	if (rf.votedFor == -1 || rf.votedFor == args.CandidateId) && upToDate {
		rf.votedFor = args.CandidateId
		reply.VoteGranted = true
		rf.resetElectionTimer()
	}
}

// ---------- log replication ----------

// broadcastLocked sends AppendEntries (or a heartbeat) to every follower.
func (rf *Raft) broadcastLocked() {
	rf.lastBroadcast = time.Now()
	for i := range rf.peers {
		if i != rf.me {
			go rf.replicateTo(i)
		}
	}
}

func (rf *Raft) replicateTo(i int) {
	rf.mu.Lock()
	if rf.dead || rf.state != Leader {
		rf.mu.Unlock()
		return
	}
	prev := rf.nextIndex[i] - 1
	entries := make([]LogEntry, len(rf.log)-(prev+1))
	copy(entries, rf.log[prev+1:])
	args := AppendEntriesArgs{
		Term:         rf.currentTerm,
		LeaderId:     rf.me,
		PrevLogIndex: prev,
		PrevLogTerm:  rf.log[prev].Term,
		Entries:      entries,
		LeaderCommit: rf.commitIndex,
	}
	rf.mu.Unlock()

	var reply AppendEntriesReply
	ok := rf.peers[i].Call("Raft.AppendEntries", &args, &reply)

	rf.mu.Lock()
	defer rf.mu.Unlock()
	// Drop failures, stale terms, and replies that no longer match nextIndex.
	if !ok || rf.dead || rf.state != Leader || rf.currentTerm != args.Term {
		return
	}
	if reply.Term > rf.currentTerm {
		rf.becomeFollower(reply.Term)
		rf.resetElectionTimer()
		return
	}
	if rf.nextIndex[i] != prev+1 {
		return
	}
	if reply.Success {
		match := prev + len(entries)
		if match > rf.matchIndex[i] {
			rf.matchIndex[i] = match
		}
		rf.nextIndex[i] = rf.matchIndex[i] + 1
		rf.advanceCommitLocked()
		return
	}
	// Log inconsistency: back up using the conflict hints, then retry.
	next := reply.ConflictIndex
	if reply.ConflictTerm != -1 {
		for j := len(rf.log) - 1; j >= 1; j-- {
			if rf.log[j].Term == reply.ConflictTerm {
				next = j + 1
				break
			}
		}
	}
	if next < 1 {
		next = 1
	}
	if next > prev { // must strictly move backwards
		next = prev
		if next < 1 {
			next = 1
		}
	}
	rf.nextIndex[i] = next
	go rf.replicateTo(i)
}

// advanceCommitLocked applies Raft's rule: only entries from the current
// term are committed by counting replicas.
func (rf *Raft) advanceCommitLocked() {
	for n := rf.lastLogIndex(); n > rf.commitIndex; n-- {
		if rf.log[n].Term != rf.currentTerm {
			break // older-term entries commit indirectly
		}
		count := 0
		for i := range rf.peers {
			if rf.matchIndex[i] >= n {
				count++
			}
		}
		if count*2 > len(rf.peers) {
			rf.commitIndex = n
			rf.applyMu.Broadcast()
			break
		}
	}
}

// AppendEntries RPC handler (also the heartbeat).
func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	reply.Success = false
	reply.ConflictIndex = 0
	reply.ConflictTerm = -1

	if args.Term < rf.currentTerm {
		reply.Term = rf.currentTerm
		return
	}
	if args.Term > rf.currentTerm {
		rf.becomeFollower(args.Term)
	}
	rf.state = Follower // a valid leader exists for this term
	rf.resetElectionTimer()
	reply.Term = rf.currentTerm

	// Consistency check.
	if args.PrevLogIndex > rf.lastLogIndex() {
		reply.ConflictIndex = len(rf.log)
		return
	}
	if rf.log[args.PrevLogIndex].Term != args.PrevLogTerm {
		reply.ConflictTerm = rf.log[args.PrevLogIndex].Term
		idx := args.PrevLogIndex
		for idx > 1 && rf.log[idx-1].Term == reply.ConflictTerm {
			idx--
		}
		reply.ConflictIndex = idx
		return
	}

	// Append new entries; truncate only on a real conflict (never on a
	// stale/duplicate RPC that carries entries we already have).
	for k, e := range args.Entries {
		pos := args.PrevLogIndex + 1 + k
		if pos < len(rf.log) {
			if rf.log[pos].Term != e.Term {
				rf.log = append(rf.log[:pos], args.Entries[k:]...)
				break
			}
		} else {
			rf.log = append(rf.log, args.Entries[k:]...)
			break
		}
	}
	reply.Success = true

	if args.LeaderCommit > rf.commitIndex {
		last := args.PrevLogIndex + len(args.Entries)
		newCommit := args.LeaderCommit
		if last < newCommit {
			newCommit = last
		}
		if newCommit > rf.commitIndex {
			rf.commitIndex = newCommit
			rf.applyMu.Broadcast()
		}
	}
}
